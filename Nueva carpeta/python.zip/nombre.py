from operator import truediv


nombre = input("Ingrese su nombre: ")
i = 0

while nombre == nombre:
    nombre = nombre
    print("ingrese nuevamente su nombre ")
    if nombre == nombre:
        print("ingrese nuevamente su nombre ")
    elif nombre == no:
        break

print("se rompio el bucle")


