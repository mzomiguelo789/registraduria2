fecha_de_nacimiento = int(input("ingrese su fecha de nacimiento "))
año_actual = int(input("ingrese el año actual "))
edad = (año_actual) - (fecha_de_nacimiento)
print("su edad es ", edad, " años")

