
#Imprimir los números entre el 5 y el 20, saltando de tres en tres.

for x in range(5,20,3):
    print(x)
