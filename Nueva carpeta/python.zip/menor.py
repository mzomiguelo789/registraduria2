numero1 = int(input(" ingrese un numero "))
numero2 = int(input(" ingrese un numero "))
if numero1 == numero2:
    print(" los 2 numero son iguales ")
elif numero1 > numero2:
    print(" el numero ", numero1, " es mayor que ", numero2)
else:
    print(" el numero ", numero2, " es mayor que ", numero1)

